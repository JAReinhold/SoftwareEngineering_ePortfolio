package com.example.mismanaged_jr;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;

    private Button buttonLogin;
    private TextView textCreateAccount;
    private TextView textForgotPassword;

    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // DB helper provides login + inventory CRUD - JR
        dbHelper = new DbHelper(this);

        // Link UI to Java variables - JR
        editUsername = findViewById(R.id.username);
        editPassword = findViewById(R.id.password);

        buttonLogin = findViewById(R.id.button);
        textCreateAccount = findViewById(R.id.button2);
        textForgotPassword = findViewById(R.id.button4);

        // LOGIN button -> validate user credentials - JR
        buttonLogin.setOnClickListener(v -> attemptLogin());

        // Create New Account -> insert user if not exists - JR
        textCreateAccount.setOnClickListener(v -> attemptCreateAccount());

        // Forgot Password -> not required for this milestone, placeholder - JR
        textForgotPassword.setOnClickListener(v ->
                Toast.makeText(this, "Password reset not implemented yet.", Toast.LENGTH_SHORT).show()
        );
    }

    private void attemptLogin() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (!isValidInput(username, password)) return;

        boolean valid = dbHelper.validateLogin(username, password);

        if (valid) {
            Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();
            goToInventory();
        } else {
            Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptCreateAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (!isValidInput(username, password)) return;

        // Prevent duplicate usernames - JR
        if (dbHelper.userExists(username)) {
            Toast.makeText(this, "That username already exists. Try logging in.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = dbHelper.createUser(username, password);

        if (created) {
            Toast.makeText(this, "Account created. You're in.", Toast.LENGTH_SHORT).show();
            goToInventory();
        } else {
            Toast.makeText(this, "Account creation failed. Try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidInput(String username, String password) {
        // Basic validation so DB calls don’t get junk - JR
        if (TextUtils.isEmpty(username)) {
            editUsername.setError("Username required");
            editUsername.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            editPassword.setError("Password required");
            editPassword.requestFocus();
            return false;
        }

        return true;
    }

    private void goToInventory() {
        Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
        startActivity(intent);
        finish(); // prevents back button returning to login after success - JR
    }
}