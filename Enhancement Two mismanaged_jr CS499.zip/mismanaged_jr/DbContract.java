package com.example.mismanaged_jr;

import android.provider.BaseColumns;

public final class DbContract {

    private DbContract() {}

    public static final class Users implements BaseColumns {
        public static final String TABLE = "users";
        public static final String COL_USERNAME = "username";
        public static final String COL_PASSWORD = "password";
    }

    public static final class Inventory implements BaseColumns {
        public static final String TABLE = "inventory";
        public static final String COL_ITEM_NAME = "item_name";
        public static final String COL_QTY = "qty";
        public static final String COL_MIN_QTY = "min_qty"; // for later SMS trigger - JR
    }
}