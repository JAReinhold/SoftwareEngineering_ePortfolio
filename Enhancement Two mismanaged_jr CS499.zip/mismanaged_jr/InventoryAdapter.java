package com.example.mismanaged_jr;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    public interface OnDeleteClickListener {
        void onDelete(long itemId);
    }

    // UPDATED: include itemName so activity can send correct SMS message - JR
    public interface OnUpdateQtyListener {
        void onUpdateQty(long itemId, String itemName, int newQty);
    }

    private final Context context;
    private List<InventoryItem> items;
    private final OnDeleteClickListener deleteListener;
    private final OnUpdateQtyListener updateListener;

    public InventoryAdapter(
            Context context,
            List<InventoryItem> items,
            OnDeleteClickListener deleteListener,
            OnUpdateQtyListener updateListener
    ) {
        this.context = context;
        this.items = items;
        this.deleteListener = deleteListener;
        this.updateListener = updateListener;
    }

    public void setItems(List<InventoryItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged(); // refresh list after DB changes - JR
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_inventory, parent, false);
        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.textItem.setText(item.getName());
        //holder.textQty.setText(String.valueOf(item.getQty()));
        String qtyDisplay = "Qty: " + item.getQty() + " / Min: " + item.getMinQty(); // added

        if (item.isLowStock()) {
            qtyDisplay += "\n!LOW STOCK!";
        }
        holder.textQty.setText(qtyDisplay);


        // Delete button per row - JR
        holder.buttonDelete.setOnClickListener(v -> deleteListener.onDelete(item.getId()));

        // Tap row to update quantity (simple update flow) - JR
        holder.itemView.setOnClickListener(v -> showUpdateQtyDialog(item));
    }

    @Override
    public int getItemCount() {
        return items == null ? 0 : items.size();
    }

    private void showUpdateQtyDialog(InventoryItem item) {
        EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("New Qty");
        input.setText(String.valueOf(item.getQty()));

        new AlertDialog.Builder(context)
                .setTitle("Update Qty")
                .setMessage(item.getName())
                .setView(input)
                .setPositiveButton("Update", (dialog, which) -> {
                    String text = input.getText().toString().trim();
                    if (text.isEmpty()) return;

                    int newQty = Integer.parseInt(text);

                    // UPDATED: pass item name too - JR
                    updateListener.onUpdateQty(item.getId(), item.getName(), newQty);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    static class InventoryViewHolder extends RecyclerView.ViewHolder {

        TextView textItem;
        TextView textQty;
        Button buttonDelete;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);

            textItem = itemView.findViewById(R.id.textRowItem);
            textQty = itemView.findViewById(R.id.textRowQty);
            buttonDelete = itemView.findViewById(R.id.buttonRowDelete);
        }
    }
}