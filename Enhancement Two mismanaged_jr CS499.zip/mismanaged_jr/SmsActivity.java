package com.example.mismanaged_jr;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    // Prefs store user choice so alerts persist between sessions - JR
    public static final String PREFS_NAME = "MisManagedPrefs";
    public static final String KEY_SMS_ENABLED = "sms_enabled";

    private Switch switchSmsAlerts;
    private TextView textPermissionStatus;
    private Button buttonTestSms;
    private Button buttonToInventory;


    private SharedPreferences prefs;

    // Permission launcher (modern permission flow) - JR
    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updatePermissionStatus();
                updateUiEnabledState();

                if (isGranted) {
                    Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS permission denied. App will still work.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Link UI - JR
        switchSmsAlerts = findViewById(R.id.switchSmsAlerts);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        buttonTestSms = findViewById(R.id.buttonTestSms);
        buttonToInventory = findViewById(R.id.buttonToInventory);

        // Load saved toggle setting - JR
        boolean savedEnabled = prefs.getBoolean(KEY_SMS_ENABLED, false);
        switchSmsAlerts.setChecked(savedEnabled);

        updatePermissionStatus();
        updateUiEnabledState();

        // Toggle -> if enabling, request permission if needed - JR
        switchSmsAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_SMS_ENABLED, isChecked).apply();

            if (isChecked && !hasSmsPermission()) {
                requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            } else {
                updateUiEnabledState();
            }
        });

        buttonToInventory.setOnClickListener(v -> {
            startActivity(new Intent(SmsActivity.this, InventoryActivity.class));
            finish();
        });

        // Test button -> try sending a message if allowed - JR
        buttonTestSms.setOnClickListener(v -> {
            if (!switchSmsAlerts.isChecked()) {
                Toast.makeText(this, "Enable SMS alerts first.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!hasSmsPermission()) {
                Toast.makeText(this, "SMS permission not granted.", Toast.LENGTH_SHORT).show();
                requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
                return;
            }

            // NOTE: For class/emulator testing, hardcode a number OR ask user input later - JR
            String testPhone = "555-123-4567"; // emulator number placeholder for teesting; replace with real # on device - JR
            String msg = "MisManagedJR Test Alert: SMS notifications are working.";

            boolean sent = SmsUtil.sendSms(testPhone, msg);

            Toast.makeText(this, sent ? "Test alert sent." : "Send failed (device/emulator may block).", Toast.LENGTH_SHORT).show();
        });
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void updatePermissionStatus() {
        if (hasSmsPermission()) {
            textPermissionStatus.setText("SMS Permission: Granted");
        } else {
            textPermissionStatus.setText("SMS Permission: Not granted");
        }
    }

    private void updateUiEnabledState() {
        // Button only usable when alerts enabled AND permission granted - JR
        boolean enabled = switchSmsAlerts.isChecked() && hasSmsPermission();
        buttonTestSms.setEnabled(enabled);
        buttonTestSms.setAlpha(enabled ? 1.0f : 0.5f);
    }
}