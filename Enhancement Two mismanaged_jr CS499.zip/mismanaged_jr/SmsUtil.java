package com.example.mismanaged_jr;

import android.telephony.SmsManager;

public class SmsUtil {

    // Sends a single SMS message - JR
    public static boolean sendSms(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (Exception e) {
            // In production you’d log this with Log.e - JR
            return false;
        }
    }
}