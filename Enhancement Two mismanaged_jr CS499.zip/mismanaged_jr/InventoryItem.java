package com.example.mismanaged_jr;

public class InventoryItem {
    private final long id;
    private final String name;
    private final int qty;
    private final int minQty; // for later SMS trigger - JR

    public InventoryItem(long id, String name, int qty, int minQty) {
        this.id = id;
        this.name = name;
        this.qty = qty;
        this.minQty = minQty;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public int getQty() { return qty; }
    public int getMinQty() { return minQty; }

    public boolean isLowStock() {
        return qty <= minQty;
    }
}