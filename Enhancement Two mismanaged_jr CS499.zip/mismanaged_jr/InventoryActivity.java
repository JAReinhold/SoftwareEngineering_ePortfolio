package com.example.mismanaged_jr;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editItemQty;
    private Button buttonAdd;

    private Button buttonSettings;
    private Button buttonLogout;

    private RecyclerView recyclerInventory;

    private DbHelper dbHelper;
    private InventoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DbHelper(this);

        // Link UI - JR
        editItemName = findViewById(R.id.editItemName);
        editItemQty = findViewById(R.id.editItemQty);
        buttonAdd = findViewById(R.id.buttonAddItem);

        buttonSettings = findViewById(R.id.button3);
        buttonLogout = findViewById(R.id.button4);

        recyclerInventory = findViewById(R.id.recyclerInventory);

        // Recycler setup: literal grid (2 columns) - JR
        recyclerInventory.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new InventoryAdapter(
                this,
                new ArrayList<>(),
                this::handleDeleteItem,
                this::handleUpdateQty
        );

        recyclerInventory.setAdapter(adapter);

        // Load initial data from DB into RecyclerView - JR
        refreshInventoryList();

        // Add new item -> Create - JR
        buttonAdd.setOnClickListener(v -> handleAddItem());

        // Settings -> go to SMS screen - JR
        buttonSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        // Log out -> return to Login - JR
        buttonLogout.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void handleAddItem() {
        String name = editItemName.getText().toString().trim();
        String qtyText = editItemQty.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            editItemName.setError("Item name required");
            editItemName.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(qtyText)) {
            editItemQty.setError("Qty required");
            editItemQty.requestFocus();
            return;
        }

        int qty;
        try {
            qty = Integer.parseInt(qtyText);
        } catch (NumberFormatException e) {
            editItemQty.setError("Qty must be a number");
            editItemQty.requestFocus();
            return;
        }

        boolean added = dbHelper.addItem(name, qty);

        if (added) {
            Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();
            editItemName.setText("");
            editItemQty.setText("");

            // Default min_qty is 1 so this behaves like your original logic, but cleaner - JR
            maybeSendLowInventoryAlert(name, qty, 1);

            refreshInventoryList(); // Read after Create - JR
        } else {
            Toast.makeText(this, "Add failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleDeleteItem(long itemId) {
        boolean deleted = dbHelper.deleteItem(itemId);

        if (deleted) {
            Toast.makeText(this, "Item deleted.", Toast.LENGTH_SHORT).show();
            refreshInventoryList(); // Read after Delete - JR
        } else {
            Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleUpdateQty(long itemId, String itemName, int newQty) {
        boolean updated = dbHelper.updateItemQty(itemId, newQty);

        // Pull min qty from DB (defaults to 1) so trigger is data-driven - JR
        int minQty = dbHelper.getMinQtyForItem(itemId);
        maybeSendLowInventoryAlert(itemName, newQty, minQty);

        if (updated) {
            Toast.makeText(this, "Qty updated.", Toast.LENGTH_SHORT).show();
            refreshInventoryList(); // Read after Update - JR
        } else {
            Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshInventoryList() {
        List<InventoryItem> items = dbHelper.getAllItems(); // Read - JR
        adapter.setItems(items);

        int lowStockCount = dbHelper.getLowInventoryItems().size();
        setTitle("MisManaged - Low Stock: " + lowStockCount);
    }

    private void maybeSendLowInventoryAlert(String itemName, int qty, int minQty) {
        SharedPreferences prefs = getSharedPreferences(SmsActivity.PREFS_NAME, MODE_PRIVATE);
        boolean smsEnabled = prefs.getBoolean(SmsActivity.KEY_SMS_ENABLED, false);

        if (!smsEnabled) return; // user turned alerts off - JR
        if (!SmsPermissionChecker.hasSmsPermission(this)) return; // no permission - JR

        if (qty <= minQty) {
            String phone = "5554"; // emulator-friendly placeholder - JR
            String msg = "MisManagedJR Alert: LOW stock for \"" + itemName + "\" (Qty=" + qty + ", Min=" + minQty + ")";
            SmsUtil.sendSms(phone, msg);
        }
    }
}