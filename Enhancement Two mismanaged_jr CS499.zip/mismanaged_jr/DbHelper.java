package com.example.mismanaged_jr;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {

    // Database settings - JR
    private static final String DB_NAME = "mismanaged.db";
    // Bump version so inventory table upgrades to include min_qty - JR
    private static final int DB_VERSION = 2;

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Create tables - JR
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + DbContract.Users.TABLE + " (" +
                        DbContract.Users._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        DbContract.Users.COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        DbContract.Users.COL_PASSWORD + " TEXT NOT NULL" +
                        ");";

        String createInventoryTable =
                "CREATE TABLE " + DbContract.Inventory.TABLE + " (" +
                        DbContract.Inventory._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        DbContract.Inventory.COL_ITEM_NAME + " TEXT NOT NULL, " +
                        DbContract.Inventory.COL_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                        DbContract.Inventory.COL_MIN_QTY + " INTEGER NOT NULL DEFAULT 1" +
                        ");";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    // Upgrade logic (simple drop/recreate for class project) - JR
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DbContract.Users.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + DbContract.Inventory.TABLE);
        onCreate(db);
    }

    // ----------------------------
    // USERS (Login / Create Account)
    // ----------------------------

    // Create new user account if username doesn't already exist - JR
    public boolean createUser(String username, String password) {
        if (userExists(username)) return false;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DbContract.Users.COL_USERNAME, username);
        values.put(DbContract.Users.COL_PASSWORD, password);

        long result = db.insert(DbContract.Users.TABLE, null, values);
        return result != -1;
    }

    // Check if username/password is valid - JR
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        String selection = DbContract.Users.COL_USERNAME + "=? AND " + DbContract.Users.COL_PASSWORD + "=?";
        String[] selectionArgs = { username, password };

        Cursor cursor = db.query(
                DbContract.Users.TABLE,
                new String[]{ DbContract.Users._ID },
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }

    // Check if a username already exists - JR
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();

        String selection = DbContract.Users.COL_USERNAME + "=?";
        String[] selectionArgs = { username };

        Cursor cursor = db.query(
                DbContract.Users.TABLE,
                new String[]{ DbContract.Users._ID },
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    // ----------------------------
    // INVENTORY CRUD
    // ----------------------------

    // Create: add a new inventory item (minQty defaults to 1 unless specified) - JR
    public boolean addItem(String name, int qty) {
        return addItem(name, qty, 1);
    }

    // Overload: add item with a custom min qty - JR
    public boolean addItem(String name, int qty, int minQty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbContract.Inventory.COL_ITEM_NAME, name);
        values.put(DbContract.Inventory.COL_QTY, qty);
        values.put(DbContract.Inventory.COL_MIN_QTY, minQty);

        long result = db.insert(DbContract.Inventory.TABLE, null, values);
        return result != -1;
    }

    // Read: get all inventory items - JR
    // sorted by urgency so the lowest-stock items appear first - JR
    public List<InventoryItem> getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        List<InventoryItem> items = new ArrayList<>();

        Cursor cursor = db.query(
                DbContract.Inventory.TABLE,
                new String[]{
                        DbContract.Inventory._ID,
                        DbContract.Inventory.COL_ITEM_NAME,
                        DbContract.Inventory.COL_QTY,
                        DbContract.Inventory.COL_MIN_QTY
                },
                null,
                null,
                null,
                null,
                DbContract.Inventory.COL_ITEM_NAME + " COLLATE NOCASE ASC"
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DbContract.Inventory._ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_QTY));
            int minQty = cursor.getInt(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_MIN_QTY)); // Added minQty compatibility to getAllItems() - JR

            items.add(new InventoryItem(id, name, qty, minQty));
        }

        cursor.close();
        return items;
    }

    // Read: filter inventory records using qty <= min_qty and return
// a prioritized list of low-stock items ordered by quantity - JR
    public List<InventoryItem> getLowInventoryItems() {
        SQLiteDatabase db = getReadableDatabase();
        List<InventoryItem> lowItems = new ArrayList<>();

        // Select only low-stock inventory items (qty <= min_qty) for prioritized review - JR
        String selection = DbContract.Inventory.COL_QTY + " <= " +
                DbContract.Inventory.COL_MIN_QTY;

        Cursor cursor = db.query(
                DbContract.Inventory.TABLE,
                new String[]{
                        DbContract.Inventory._ID,
                        DbContract.Inventory.COL_ITEM_NAME,
                        DbContract.Inventory.COL_QTY,
                        DbContract.Inventory.COL_MIN_QTY
                },
                selection,
                null,
                null,
                null,
                DbContract.Inventory.COL_QTY + " ASC, " +
                        DbContract.Inventory.COL_ITEM_NAME + " COLLATE NOCASE ASC"
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DbContract.Inventory._ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_QTY));
            int minQty = cursor.getInt(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_MIN_QTY));

            lowItems.add(new InventoryItem(id, name, qty, minQty));
        }

        cursor.close();
        return lowItems;
    }

    // Update: change qty for a specific item - JR
    public boolean updateItemQty(long itemId, int newQty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbContract.Inventory.COL_QTY, newQty);

        int rows = db.update(
                DbContract.Inventory.TABLE,
                values,
                DbContract.Inventory._ID + "=?",
                new String[]{ String.valueOf(itemId) }
        );

        return rows > 0;
    }

    // Optional Update: change min qty for a specific item - JR
    public boolean updateItemMinQty(long itemId, int newMinQty) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbContract.Inventory.COL_MIN_QTY, newMinQty);

        int rows = db.update(
                DbContract.Inventory.TABLE,
                values,
                DbContract.Inventory._ID + "=?",
                new String[]{ String.valueOf(itemId) }
        );

        return rows > 0;
    }

    // Optional Read: fetch min qty for a specific item (fallback 1) - JR
    public int getMinQtyForItem(long itemId) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                DbContract.Inventory.TABLE,
                new String[]{ DbContract.Inventory.COL_MIN_QTY },
                DbContract.Inventory._ID + "=?",
                new String[]{ String.valueOf(itemId) },
                null,
                null,
                null
        );

        int minQty = 1;
        if (cursor.moveToFirst()) {
            minQty = cursor.getInt(cursor.getColumnIndexOrThrow(DbContract.Inventory.COL_MIN_QTY));
        }
        cursor.close();
        return minQty;
    }

    // Delete: remove an item - JR
    public boolean deleteItem(long itemId) {
        SQLiteDatabase db = getWritableDatabase();

        int rows = db.delete(
                DbContract.Inventory.TABLE,
                DbContract.Inventory._ID + "=?",
                new String[]{ String.valueOf(itemId) }
        );

        return rows > 0;
    }
}