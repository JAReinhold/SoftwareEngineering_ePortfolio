// SNHU
// CS-320
// Project One
// Jacob Reinhold
// 10AUG2025


package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;
    private Contact contact;

    // Set up a known contact before each test
    @BeforeEach
    void setUp() {
        contactService = new ContactService();
        contact = new Contact("00001", "Anakin", "Skywalker", "5554443321", "003 Death Star lane");
        contactService.addContact(contact);
    }

    // Test adding a new contact
    @Test
    void testAddContact() {
        Contact newContact = new Contact("00002", "Luke", "Skywalker", "5554443333", "456 Tatooine Ave");
        contactService.addContact(newContact);

    }

    // Test that adding a contact with a duplicate ID throws an exception
    @Test
    void testAddDuplicateContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(new Contact("00001", "Padme", "Amidala", "5554442222", "012 Alderaan Rd"));
        });
    }

    // Test deleting a contact and confirm it's no longer in the list
    @Test
    void testDeleteContact() {
        contactService.deleteContact("00001");
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("00001"); // Already deleted
        });
    }

    // Test updating the first name field
    @Test
    void testUpdateFirstName() {
        contactService.updateFirstName("00001", "Leia");
        assertEquals("Leia", contact.getFirstName());
    }

    // Test updating the last name field
    @Test
    void testUpdateLastName() {
        contactService.updateLastName("00001", "Organa");
        assertEquals("Organa", contact.getLastName());
    }

    // Test updating the phone number field
    @Test
    void testUpdatePhone() {
        contactService.updatePhone("00001", "2223334444");
        assertEquals("2223334444", contact.getPhone());
    }

    // Test updating the address field
    @Test
    void testUpdateAddress() {
        contactService.updateAddress("00001", "321 Dagobah Blvd");
        assertEquals("321 Dagobah Blvd", contact.getAddress());
    }

    // Test updating a contact that doesn’t exist
    @Test
    void testUpdateInvalidContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateFirstName("Nope", "Yoda");
        });
    }
}
