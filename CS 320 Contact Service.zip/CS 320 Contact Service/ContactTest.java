// SNHU
// CS-320
// Project One
// Jacob Reinhold
// 10AUG2025


package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Test successful creation of a contact
    @Test
    void testContactCreation() {
        Contact contact = new Contact("00001", "Anakin", "Skywalker", "5554443321", "003 Death Star lane");
        assertEquals("00001", contact.getContactId());
        assertEquals("Anakin", contact.getFirstName());
        assertEquals("Skywalker", contact.getLastName());
        assertEquals("5554443321", contact.getPhone());
        assertEquals("003 Death Star lane", contact.getAddress());
    }

    // Test invalid contact ID (too long)
    @Test
    void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678910", "Anakin", "Skywalker", "5554443321", "003 Death Star lane");
        });
    }

    // Test invalid first name (null)
    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("00001", null, "Skywalker", "5554443321", "003 Death Star lane");
        });
    }

    // Test invalid last name (too long)
    @Test
    void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("00001", "Anakin", "SkywalkerOrganaSolo", "5554443321", "003 Death Star lane");
        });
    }

    // Test invalid phone number (not 10 digits)
    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("00001", "Anakin", "Skywalker", "123", "003 Death Star lane");
        });
    }

    // Test invalid address (null)
    @Test
    void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("00001", "Anakin", "Skywalker", "5554443321", null);
        });
    }

    // Test setting a new valid first name
    @Test
    void testSetFirstName() {
        Contact contact = new Contact("00001", "Anakin", "Skywalker", "5554443321", "003 Death Star lane");
        contact.setFirstName("Leia");
        assertEquals("Leia", contact.getFirstName());
    }

    // Test setting an invalid phone number
    @Test
    void testSetInvalidPhone() {
        Contact contact = new Contact("00001", "Anakin", "Skywalker", "5554443321", "003 Death Star lane");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("1234");
        });
    }

    // Test setting a new valid address
    @Test
    void testSetAddress() {
        Contact contact = new Contact("00001", "Anakin", "Skywalker", "5554443321", "003 Death Star lane");
        contact.setAddress("321 Dagobah Blvd");
        assertEquals("321 Dagobah Blvd", contact.getAddress());
    }
}
