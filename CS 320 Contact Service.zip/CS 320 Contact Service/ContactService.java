// SNHU
// CS-320
// Project One
// Jacob Reinhold
// 10AUG2025

package contactservice;

import java.util.ArrayList;

public class ContactService {
    // List to store all contact objects
    private ArrayList<Contact> contactList;

    // Constructor initializes the contact list
    public ContactService() {
        this.contactList = new ArrayList<>();
    }

    // Adds a new contact if the ID is unique
    public void addContact(Contact contact) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contact.getContactId())) {
                throw new IllegalArgumentException("Contact ID already exists");
            }
        }
        contactList.add(contact);
    }

    // Deletes a contact by ID
    public void deleteContact(String contactId) {
        Contact toRemove = null;
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                toRemove = c;
                break;
            }
        }
        if (toRemove != null) {
            contactList.remove(toRemove);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    // Updates the first name of a contact by ID
    public void updateFirstName(String contactId, String newFirstName) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setFirstName(newFirstName);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

    // Updates the last name of a contact by ID
    public void updateLastName(String contactId, String newLastName) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setLastName(newLastName);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

    // Updates the phone number of a contact by ID
    public void updatePhone(String contactId, String newPhone) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setPhone(newPhone);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

    // Updates the address of a contact by ID
    public void updateAddress(String contactId, String newAddress) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setAddress(newAddress);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }
}
