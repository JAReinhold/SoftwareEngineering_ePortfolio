// SNHU
// CS-320
// Project One
// Jacob Reinhold
// 10AUG2025
// UPDATED for CS-499 31MAY2026
// Original code that was enhanced has been pushed to the bottom of the file to show changes.
// My goal was to reduce the amount of code it took to achieve the same goal. I added a HashMap for use rather than
// continuing to utilize an array.
package contactservice;

// import java.util.ArrayList;  No longer needed as HashMap is being utilized
import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact can't be null!");
        }
        String contactId = contact.getContactId();

        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID already exists!");
        }

        contacts.put(contactId, contact);
    }

    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found!");
        }

        contacts.remove(contactId);
    }

    private Contact findContactById(String contactId) {
        Contact contact = contacts.get(contactId);

        if (contact == null) {
            throw new IllegalArgumentException("Contact not found!");
        }

        return contact;
    }

    public void updateFirstName(String contactId, String newFirstName) {
        findContactById(contactId).setFirstName(newFirstName);
    }

    public void updateLastName(String contactId, String newLastName) {
        findContactById(contactId).setLastName(newLastName);
    }

    public void updatePhone(String contactId, String newPhone) {
        findContactById(contactId).setPhone(newPhone);
    }

    public void updateAddress(String contactId, String newAddress) {
        findContactById(contactId).setAddress(newAddress);
    }
}

/*public class ContactService {
    // List to store all contact objects
    private ArrayList<Contact> contactList;

    // Constructor initializes the contact list
    public ContactService() {
        this.contactList = new ArrayList<>();
    }
*/

/*    // Adds a new contact if the ID is unique
    public void addContact(Contact contact) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contact.getContactId())) {
                throw new IllegalArgumentException("Contact ID already exists");
            }
        }
        contactList.add(contact);
    }
*/

/*    // Deletes a contact by ID
    public void deleteContact(String contactId) {
        Contact toRemove = null;
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                toRemove = c;
                break;
            }
        }
        if (toRemove != null) {
            contactList.remove(toRemove);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }
*/

// Updates the first name of a contact by ID
/*    public void updateFirstName(String contactId, String newFirstName) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setFirstName(newFirstName);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

    // Updates the last name of a contact by ID
    public void updateLastName(String contactId, String newLastName) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setLastName(newLastName);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

    // Updates the phone number of a contact by ID
    public void updatePhone(String contactId, String newPhone) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setPhone(newPhone);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

    // Updates the address of a contact by ID
    public void updateAddress(String contactId, String newAddress) {
        for (Contact c : contactList) {
            if (c.getContactId().equals(contactId)) {
                c.setAddress(newAddress);
                return;
            }
        }
        throw new IllegalArgumentException("Contact not found");
    }

 */
