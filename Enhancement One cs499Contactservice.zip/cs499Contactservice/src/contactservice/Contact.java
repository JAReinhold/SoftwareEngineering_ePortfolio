// SNHU
// CS-320
// Project One
// Jacob Reinhold
// 10AUG2025
// UPDATED for CS-499 31MAY2026


package contactservice;

public class Contact {
    private final String contactId; //Immutable
    private String firstName;
    private String lastName;
    private String phone;
    private String address;


    // Constructor for rule validation
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid Contact ID");
        }

        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid First Name");
        }

        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid Last Name");
        }

       /*if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Invalid Phone");
        }*/

        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid Phone");
        }

        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid Address");
        }


        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;

    }

// Getters and Setters


    //Gets the contact ID
    public String getContactId() {
        return contactId;
    }

    //Gets the first name
    public String getFirstName() {
        return firstName;
    }

    //Sets and validates the first name
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid First Name");
        }
        this.firstName = firstName;
    }

    //Gets the last name
    public String getLastName() {
        return lastName;
    }

    //Sets and validates the last name
    public void setLastName(String lastName) {
        if(lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }

    // Gets the phone number
    public String getPhone() {
        return phone;
    }

    //Sets and validates the phone number
    public void setPhone(String phone) {
        /*if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Invalid Phone");
        }*/

        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid Phone");
        }
        this.phone = phone;
    }

    //Gets the address
    public String getAddress() {
        return address;
    }

    // Sets and validates the address
    public void setAddress(String address) {
        if(address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invald address");
        }
        this.address = address;
    }
}